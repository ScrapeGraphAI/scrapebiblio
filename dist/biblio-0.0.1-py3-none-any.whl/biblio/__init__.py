
"""
__init__.py module
"""

from .pipeline import process_pdf
